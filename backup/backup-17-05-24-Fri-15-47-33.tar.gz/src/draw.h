#pragma once

#include "globals.h"
#include "utility.h"

#include <cstdint>
#include <xcb/xcb.h>
#include <xcb/xproto.h>

namespace mwm
{
    
}